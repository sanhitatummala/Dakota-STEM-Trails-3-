# Dakota STEM Trails website

Every file sits in one folder (no subfolders), so you can upload them all to GitHub in one go.

## Files
- Pages: index.html (Home), about.html, contact.html, team.html, 404.html
- styles.css: colors, fonts, layout, animations
- main.js: animations, mobile menu, contact form
- 10 .jpg photos

All of these files must be in the top level of the GitHub repo, next to index.html.

## Upload / update on GitHub
1. Open the repo on github.com, then click Add file, then Upload files.
2. Select ALL the files in this folder at once (Cmd+A in the file picker) and drop them in.
3. Click Commit changes. Vercel redeploys on its own in about a minute.

## Contact form
Messages go to dakotastemtrails@gmail.com through FormSubmit. The first time the form is used on the live site,
FormSubmit emails an activation link to that inbox. Click it once.

## Editing
- Text: open a page on GitHub, click the pencil icon, edit, then commit.
- Photos: upload a new photo with the exact same file name to replace the old one.
- Colors: change the variables at the top of styles.css.
